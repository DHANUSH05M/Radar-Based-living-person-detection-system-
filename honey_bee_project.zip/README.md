# Bio-Inspired Human Detection System

ESP32 + RCWL sensors + Honey Bee Algorithm

## WiFi
SSID: HoneyBeeHive
Password: 12345678
Open: http://192.168.4.1

## Pins
TILE1 -> 13
TILE2 -> 14
TILE3 -> 27
RED -> 25
GREEN -> 26
BLUE -> 33
BUZZER -> 4
