#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "HoneyBeeHive";
const char* password = "12345678";

#define TILE1 13
#define TILE2 14
#define TILE3 27

#define RED   25
#define GREEN 26
#define BLUE  33
#define BUZZER 4

float hiveConfidence = 0;
float recruitRate = 0.6;
float abandonRate = 0.2;
float threshold = 4.0;

WebServer server(80);

void handleRoot() {
  String statusText = "SAFE";
  String color = "blue";

  if (hiveConfidence >= threshold) {
    statusText = "HUMAN DETECTED";
    color = "red";
  }

  String page = "<html><body style='text-align:center;'>";
  page += "<h1>Honey Bee Dashboard</h1>";
  page += "<h2>Confidence: " + String(hiveConfidence) + "</h2>";
  page += "<h2 style='color:" + color + ";'>" + statusText + "</h2>";
  page += "</body></html>";

  server.send(200, "text/html", page);
}

void setup() {
  Serial.begin(115200);

  pinMode(TILE1, INPUT_PULLDOWN);
  pinMode(TILE2, INPUT_PULLDOWN);
  pinMode(TILE3, INPUT_PULLDOWN);

  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  digitalWrite(BLUE, HIGH);

  WiFi.softAP(ssid, password);

  server.on("/", handleRoot);
  server.begin();
}

void loop() {
  int t1 = digitalRead(TILE1);
  int t2 = digitalRead(TILE2);
  int t3 = digitalRead(TILE3);

  int activeTiles = 0;
  if (t1 == HIGH) activeTiles++;
  if (t2 == HIGH) activeTiles++;
  if (t3 == HIGH) activeTiles++;

  if (activeTiles >= 2)
    hiveConfidence += recruitRate;
  else
    hiveConfidence -= abandonRate;

  if (hiveConfidence < 0)
    hiveConfidence = 0;

  if (hiveConfidence >= threshold) {
    digitalWrite(RED, HIGH);
    digitalWrite(BLUE, LOW);
    digitalWrite(BUZZER, HIGH);
  } else {
    digitalWrite(RED, LOW);
    digitalWrite(BLUE, HIGH);
    digitalWrite(BUZZER, LOW);
  }

  server.handleClient();
  delay(300);
}
